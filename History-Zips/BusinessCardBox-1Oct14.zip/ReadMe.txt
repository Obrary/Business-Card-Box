Product: Business Card Box, September 2014

Designer: Scott Austin, scotta@obrary.com

Support:  support@obrary.com

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The business card box is cut on a laser cutter from 1/4" plywood.